package com.sure.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetailWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetailWebApplication.class, args);
	}
}
