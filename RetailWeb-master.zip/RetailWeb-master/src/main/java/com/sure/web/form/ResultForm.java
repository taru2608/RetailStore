package com.sure.web.form;

import java.util.List;

public class ResultForm {
	
	private long userId;
	private String userName;
	private String UserType;
	private long totalCost;
	private int discount;
	private long productId;
	private String producttype;
	private long actualprice;
	public String getProducttype() {
		return producttype;
	}
	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserType() {
		return UserType;
	}
	public void setUserType(String userType) {
		UserType = userType;
	}
	public long getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(long totalCost) {
		this.totalCost = totalCost;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public long getActualprice() {
		return actualprice;
	}
	public void setActualprice(long actualprice) {
		this.actualprice = actualprice;
	}
	
	
	

}
